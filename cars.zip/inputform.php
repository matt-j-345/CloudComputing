<!DOCTYPE html>
<html>
  <head>
	<link rel="stylesheet" href="style.css">
  </head>
  <body>
	<form method="post" action="" name="input-car-form" enctype="multipart/form-data">
	  <div class="form-element"><label>Make</label><input type="text" name="make" required /> </div>
      <div class="form-element"><label>Model</label><input type="text" name="model" required /></div>
      <div class="form-element"><label>Year</label><input type="text" name="year" required /></div>	  
      <div class="form-element"><label>Fuel Type</label><input type="text" name="fuel" required /></div>	  
      <div class="form-element"><label>Transmission</label><input type="text" name="transmission" required /></div>
      <div class="form-element"><label>Colour</label><input type="text" name="colour" required /></div>	  
      <div class="form-element"><label>CC</label><input type="text" name="cc" required /></div>
	  <div class="form-element"><label>HP</label><input type="text" name="hp" required /></div>
	  <div class="form-element"><label>Filename</label><input type="" name="filename" /><br/>
	  <br>
	  <button type="submit" name="submit" value="submit">Submit Data</button>
	</form>	

<?php 

	$filename = "assets/" . $_POST['filename'];

?>
	
	<form class="formsmall" action="https://group1-cmp6210-public.s3.amazonaws.com/" method="post" enctype="multipart/form-data">
	<input type="hidden" name="key" value="<?php echo $filename; ?>" /><br/>
	<input type="file" name="file" /> <br />
	<button type="submit" name="submit" value="submit">Submit Image</button>
	</form>
	<a href="index.php">Back to car list</a>	
	<p>
<?php

error_reporting(E_ERROR | E_PARSE);

$conn = new mysqli("group1-db.co9ml5nbp7mf.us-east-1.rds.amazonaws.com", "main", "carscarscars", "cars");

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}



if(isset($_POST['submit'])){

	$make = $_POST['make'];
	$model = $_POST['model'];
	$year = $_POST['year'];
	$fuel = $_POST['fuel'];
	$transmission = $_POST['transmission'];
	$colour = $_POST['colour'];
	$cc = $_POST['cc'];
	$hp = $_POST['hp'];
	
	$file = trim(strstr($filename, "/"),'/');
	
	$sql = 	"INSERT INTO `cars`(`make`, `model`, `year`, `fuel`, `transmission`, `colour`, `cc`, `hp`, `image`) VALUES ('$make','$model',$year,'$fuel','$transmission','$colour',$cc,$hp,'$file')";

	if ($conn->query($sql) === TRUE) {
		echo "New database record created successfully";
	} 
	
	#else {
	#	echo "Error: " . $sql . "<br>" . $conn->error;
	#}

$conn->close();

}else{

	$make = "";
	$model = "";
	$year = "";
	$fuel = "";
	$transmission = "";
	$colour = "";
	$cc = "";
	$hp = "";
	$filename = "";
	$_FILES['image_upload'] = "";
}

?>
  </body>
</html>