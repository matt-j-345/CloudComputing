<!DOCTYPE html>
<html>
  <head>
	<link rel="stylesheet" href="style.css">
  </head>
  <body>
<p>
<a href="inputform.php">Add your own car</a>
<p> 
<a href="php.php">PHP info for debugging</a>
<?php

$conn = new mysqli("group1-db.co9ml5nbp7mf.us-east-1.rds.amazonaws.com", "main", "carscarscars", "cars");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM cars";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
	
	echo "<center>
		  <div class='tableFixHead'>
		  <table class='styled-table'>
		  <TR>
		  <TH>Make</TH>
		  <TH>Model</TH>
		  <TH>Year</TH>
		  <TH>Fuel</TH>
		  <TH>Transmission</TH>
		  <TH>Colour</TH>
		  <TH>HP</TH>
		  <TH>Image</TH>
		  </TR>"; 
    while($row = mysqli_fetch_assoc($result)) {
        echo "<TR>
		<TD><center>" . $row["make"]. "</center></TD>
		<TD><center>" . $row["model"]. "</center></TD>
		<TD><center>" . $row["year"]. "</center></TD>
		<TD><center>" . $row["fuel"]. "</center></TD>
		<TD><center>" . $row["transmission"]. "</center></TD>
		<TD><center>" . $row["colour"]. "</center></TD>
		<TD><center>" . $row["hp"]. "</center></TD>
		<TD><center><img src='https://group1-cmp6210-public.s3.amazonaws.com/assets/" . $row["image"]. "' height='75'></center></TD>
		</TR>";
		 
    }
	echo "</table>
		  </div>
		  </center>";
} else {
    echo "0 results";
}

mysqli_close($conn);



?>


  </body>
</html>