-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2023 at 11:54 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cars`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(11) NOT NULL,
  `make` varchar(100) NOT NULL,
  `model` varchar(150) NOT NULL,
  `year` int(11) NOT NULL,
  `fuel` varchar(10) NOT NULL,
  `transmission` varchar(15) NOT NULL,
  `colour` varchar(25) NOT NULL,
  `cc` int(11) NOT NULL,
  `hp` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `make`, `model`, `year`, `fuel`, `transmission`, `colour`, `cc`, `hp`, `image`) VALUES
(2, 'Honda', 'Amaze 1.2 VX i-VTEC', 2017, 'Petrol', 'Manual', 'Grey', 1198, 87, 'Amaze 1.2 VX i-VTEC 2017 (CAR 1).jpg'),
(3, 'Maruti Suzuki', 'Swift DZire VDI', 2014, 'Diesel', 'Manual', 'White', 1248, 74, 'Swift DZire VDI 2014 (CAR 2).jpg'),
(4, 'Hyundai', 'i10 Magna 1.2 Kappa2', 2011, 'Petrol', 'Manual', 'Maroon', 1197, 79, 'i10 Magna 1.2 Kappa2 2011 (CAR 3).jpg'),
(5, 'Toyota', 'Glanza G', 2019, 'Petrol', 'Manual', 'Red', 1197, 82, 'Glanza G 2019 (CAR 4).jpeg'),
(6, 'Toyota', 'Innova 2.4 VX 7 STR', 2018, 'Diesel', 'Manual', 'Grey', 2393, 148, 'Innova 2.4 VX 7 STR [2016-2020] (CAR 5).jpeg'),
(7, 'Maruti Suzuki', 'Ciaz ZXi', 2017, 'Petrol', 'Manual', 'Grey', 1373, 91, 'Ciaz ZXi 2017 (CAR 6).jpg'),
(8, 'Mercedes-Benz', 'CLA 200 Petrol Sport', 2015, 'Petrol', 'Automatic', 'White', 1991, 181, 'CLA 200 Petrol Sport 2015 (CAR 7).jpg'),
(9, 'BMW', 'X1 xDrive20d M Sport', 2017, 'Diesel', 'Automatic', 'White', 1995, 188, 'X1 xDrive20d M Sport 2017 (CAR 8).jpg'),
(10, 'Skoda', 'Octavia 1.8 TSI Style Plus AT', 2017, 'Petrol', 'Automatic', 'White', 1798, 177, 'Octavia 1.8 TSI Style Plus AT [2017] (CAR 9).jpg'),
(11, 'Nissan', 'Terrano XL', 2015, 'Diesel', 'Manual', 'White', 1461, 84, 'Terrano XL (D) 2015 (CAR 10).jpeg'),
(12, 'Hyundai', 'Elite i20 Sportz 1.2', 2017, 'Petrol', 'Manual', 'Red', 1197, 82, 'Elite i20 Sportz 1.2 2017 (CAR 11).jpg'),
(13, 'Renault', 'Kwid 1.0 RXT', 2018, 'Petrol', 'Manual', 'Grey', 999, 67, 'Kwid 1.0 RXT [2016-2019] (CAR 12).jpg'),
(14, 'Maruti Suzuki', 'Ciaz Alpha Hybrid 1.5 AT', 2019, 'Petrol', 'Automatic', 'Blue', 1462, 103, 'Ciaz Alpha Hybrid 1.5 AT [2018-2020] (CAR 13).jpg'),
(15, 'Tata', 'Harrier XZ', 2019, 'Diesel', 'Manual', 'Orange', 1956, 138, 'Harrier XZ [2019-2020] (CAR 14).jpg'),
(16, 'Volkswagen', 'Polo GT TSI', 2017, 'Petrol', 'Automatic', 'Grey', 1197, 103, 'Polo GT TSI 2017 (CAR 15).jpeg'),
(17, 'Maruti Suzuki', 'Celerio ZXi AMT', 2016, 'Petrol', 'Automatic', 'Red', 998, 67, 'Celerio ZXi AMT [2019-2020] (CAR 16).jpeg'),
(18, 'Maruti Suzuki', 'Alto 800 Lxi', 2019, 'Petrol', 'Manual', 'Grey', 796, 47, 'Alto 800 LXi (O) (CAR 17).jpg'),
(19, 'Maruti Suzuki', 'Baleno Alpha Automatic', 2018, 'Petrol', 'Automatic', 'Grey', 1197, 82, 'Baleno Alpha Automatic 2018 (CAR 18).jpeg'),
(20, 'Maruti Suzuki', 'Wagon R ZXi 1.2 AMT', 2020, 'Petrol', 'Automatic', 'White', 1197, 82, 'Wagon R ZXi 1.2 AMT (CAR 19).png'),
(21, 'Hyundai', 'Creta 1.6 E Petrol', 2016, 'Petrol', 'Manual', 'Silver', 1591, 122, 'Creta 1.6 E Petrol 2016 (CAR 20).jpeg'),
(22, 'Maruti Suzuki', 'S-Presso VXi AMT', 2020, 'Petrol', 'Automatic', 'Grey', 998, 67, 'S-Presso VXi AMT 2020 (CAR 21).jpeg'),
(23, 'Volkswagen', 'Vento Comfortline Petrol AT', 2015, 'Petrol', 'Automatic', 'Brown', 1197, 103, 'Vento Comfortline Petrol AT 2015 (CAR 22).jpeg'),
(24, 'Hyundai', 'Santro Sportz AMT', 2018, 'Petrol', 'Automatic', 'White', 1086, 68, 'Santro Sportz AMT [2018-2020] (CAR 23).jpeg'),
(25, 'Hyundai', 'Venue SX 1.0', 2019, 'Petrol', 'Manual', 'Blue', 998, 118, 'Venue SX 1.0 (O) Petrol [2019-2020] (CAR 24).jpg'),
(26, 'Maruti Suzuki', 'Alto LXi CNG', 2019, 'CNG', 'Manual', 'Grey', 998, 58, 'Alto LXi CNG 2019 (CAR 25).jpg'),
(27, 'Maruti Suzuki', 'Ritz Zxi BS-IV', 2013, 'Petrol', 'Manual', 'Grey', 1197, 85, 'Ritz Zxi BS-IV 2013 (CAR 26).jpg'),
(28, 'Hyundai', 'Creta 1.6 SX Plus Petrol', 2019, 'Petrol', 'Manual', 'Grey', 1591, 122, 'Creta 1.6 SX Plus Petrol 2019 (CAR 27).jpeg'),
(29, 'Honda', 'Brio V MT', 2014, 'Petrol', 'Manual', 'Red', 1198, 87, 'Brio V MT 2-14 (CAR 28).png'),
(30, 'Hyundai', 'Elite i20 Asta 1.2', 2015, 'Petrol', 'Manual', 'White', 1197, 82, 'Elite i20 Asta 1.2 2015 (CAR 29).jpg'),
(31, 'Honda', 'WR-V VX MT Petrol', 2018, 'Petrol', 'Manual', 'White', 1199, 89, 'WR-V VX MT Petrol 22018 (CAR 30).jpg'),
(32, 'Hyundai', 'Venue SX 1.0 Turbo iMT', 2020, 'Petrol', 'Manual', 'Blue', 998, 118, 'Venue SX 1.0 Turbo iMT 2020 (CAR 31).jpg'),
(33, 'Hyundai', 'Creta 1.6 SX Plus AT', 2016, 'Diesel', 'Automatic', 'Black', 1582, 126, 'Creta 1.6 SX Plus AT 2016 (CAR 32).jpg'),
(34, 'Ford', 'Ecosport Titanium 1.0L EcoBoost', 2015, 'Petrol', 'Manual', 'Silver', 999, 124, 'Ecosport Titanium+ 1.0L EcoBoost 2015 (CAR 33).jpg'),
(35, 'Hyundai', 'Santro GL', 2009, 'CNG', 'Manual', 'Silver', 1086, 62, 'Santro GL (CNG) 2009 ( CAR 34).jpg'),
(36, 'Audi', 'A3 Sport', 2017, 'Petrol', 'Automatic', 'White', 1500, 148, '780e6041877e4b77a18699f31156b642.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
